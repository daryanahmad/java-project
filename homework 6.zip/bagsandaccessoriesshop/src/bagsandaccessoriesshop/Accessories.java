
package bagsandaccessoriesshop;


public interface Accessories {
     void Price(double a);
     void Type(String b);
     void Size(int c);
}
class necklace implements Accessories{
double price;
int size;
String Type;
public void Price(double a){
  price=a;
    System.out.println("the price is "+price+" Dollars");

}
public void Type(String b){
  Type=b;
    System.out.println("the necklace Type is"+Type+" ");
}
public void Size(int c){
   size=c;
    System.out.println("the necklace Size is"+size+" x's");
}}

