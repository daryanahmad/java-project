
package bagsandaccessoriesshop;


public class AccessoriesBusiness {
  String name;
  private String BusinesType;
  private String Location;
  private int Size;
 
  public void myshop(){
      System.out.println("welcome to our shop");
  }
  AccessoriesBusiness (){
  name="daryan";}
  

    public String getName() {
        return name;
    }

    public String getBusinesType() {
        return BusinesType;
    }

    public String getLocation() {
        return Location;
    }

    public int getSize() {
        return Size;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBusinesType(String BusinesType) {
        this.BusinesType = BusinesType;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public void setSize(int Size) {
        this.Size = Size;
    }

  
    
    
    
   
    
}
