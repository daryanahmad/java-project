
package bagsandaccessoriesshop;


public class ItemPriceAndSales extends AccessoriesBusiness {
    String itemBrand;
    String itemID;
    String vender;
    String itemDivsion;
  
  
  
  
  
  
  
}
