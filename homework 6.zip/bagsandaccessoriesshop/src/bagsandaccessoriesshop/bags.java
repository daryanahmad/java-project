
package bagsandaccessoriesshop;


public class bags extends AccessoriesBusiness {
        String bagbrand;
        String bagID;
        String vender;
        String bagDivsion;
  
    
    
    
}
