
package bagsandaccessoriesshop;


public  class customer {
   String name;

employee allemployees[];

    public customer(String name, employee[] employees) {
        this.name = name;
        this.allemployees = employees;
    }

public employee[]getemployees(){
return allemployees;
}
   
   public static void main(String[] args) {
employee obj=new employee("daryan",1234567);
employee obj1=new employee("zhyar",223344);
employee listofemployees[]=new employee[2];
listofemployees[0]=obj;
listofemployees[1]=obj1;

   customer d=new customer("haryad",listofemployees);
       for (int i = 0; i < listofemployees.length; i++) {
           
           System.out.println(listofemployees[i].name);
           System.out.println(listofemployees[i].id);
           System.out.println("&&&&&&&&&&&&&&&&&&&&&&");
       }
   }
  
}
