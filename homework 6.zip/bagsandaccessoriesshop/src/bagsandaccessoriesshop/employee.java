
package bagsandaccessoriesshop;


public class employee  {
    String name;
    int id;

    public employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

 
   
  
  
}
