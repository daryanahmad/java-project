
package bagsandaccessoriesshop;


public class shoes extends AccessoriesBusiness{
       String shoesbrand;
       String shoesID;
       String vender;
       String shoesDivsion;
  
  
}
